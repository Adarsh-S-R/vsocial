This PHP vulnerable web app is built for educational purpose only to understand and learn Web Application Firewall concepts. Host it in a VM or XAMPP server locally. 
