directory for PhotoAlbums
